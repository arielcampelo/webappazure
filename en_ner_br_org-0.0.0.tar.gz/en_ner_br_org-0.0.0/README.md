| Feature | Description |
| --- | --- |
| **Name** | `en_ner_br_org` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.6.1,<3.7.0` |
| **Default Pipeline** | `tok2vec`, `ner`, `find_name` |
| **Components** | `tok2vec`, `ner`, `find_name` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `ORG` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `ENTS_F` | 99.15 |
| `ENTS_P` | 99.15 |
| `ENTS_R` | 99.15 |
| `TOK2VEC_LOSS` | 0.02 |
| `NER_LOSS` | 0.00 |