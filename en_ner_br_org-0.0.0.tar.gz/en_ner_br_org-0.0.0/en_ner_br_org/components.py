import spacy
from spacy.tokenizer import Tokenizer
from spacy.language import Language
from spacy.tokens import Doc, Span

import re 

@spacy.registry.callbacks("customize_tokenizer")
def make_customize_tokenizer():
    def customize_tokenizer(nlp):
        nlp.tokenizer = Tokenizer(nlp.vocab, token_match=re.compile(r'\S+').match)
    return customize_tokenizer




@spacy.Language.component("find_name")
def find_name(doc):
    name_endings = ['LIMITED', 'LTDA', 'LTD']
    has_name = any(entity.label_ == 'ORG' for entity in doc.ents)
    if not has_name:
        org_start = 0
        org_end = 0
        span_index = 0
        for token in doc:
            span_index += 1
            for ending in name_endings:
                ending_index = token.text.find(ending)
                if ending_index != -1:
                    org_end = span_index
                    break
                if org_end != 0:
                    break
        if org_end > org_start:
            new_entity = Span(doc, org_start, org_end, label="ORG")
            doc.ents = list(doc.ents) + [new_entity] 
    return doc
