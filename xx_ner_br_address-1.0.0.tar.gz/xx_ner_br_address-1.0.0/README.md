| Feature | Description |
| --- | --- |
| **Name** | `xx_ner_br_address` |
| **Version** | `1.0.0` |
| **spaCy** | `>=3.5.3,<3.6.0` |
| **Default Pipeline** | `tok2vec`, `ner`, `entity_ruler`, `context_matcher_br` |
| **Components** | `tok2vec`, `ner`, `entity_ruler`, `context_matcher_br` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (12 labels for 2 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `ADR`, `CIT`, `CMP`, `CNT`, `CSD`, `EML`, `PCD`, `PER`, `PHN`, `SIF`, `STA` |
| **`entity_ruler`** | `BDT` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `ENTS_F` | 97.50 |
| `ENTS_P` | 97.25 |
| `ENTS_R` | 97.74 |
| `TOK2VEC_LOSS` | 22573.75 |
| `NER_LOSS` | 100921.52 |