import spacy
from spacy.tokenizer import Tokenizer
from spacy.language import Language
from spacy.tokens import Doc, Span
from spacy.matcher import Matcher
import re 
from pathlib import Path
import json 
import os 
import string 


@spacy.registry.callbacks("customize_tokenizer")
def make_customize_tokenizer():
    def customize_tokenizer(nlp):
        nlp.tokenizer = Tokenizer(nlp.vocab, token_match=re.compile(r'\S+').match)
    return customize_tokenizer



@Language.factory('context_matcher_br')
def add_context_matcher(nlp, name):
    return ContextMatcher(nlp, name)

class ContextMatcher:
    
    def __init__(self, nlp: spacy.Language, name):
        self.nlp = nlp
        self.name = name 
        self.overwrite = True
        self.patterns = []
        if os.path.exists('context_matcher_patterns.jsonl'):
            data = []
            with open("context_matcher_patterns.jsonl", 'r', encoding='utf-8') as file:
                for line in file:
                    if len(line.strip())!= 0 and line.strip().startswith('#') == False:
                        item = json.loads(line.strip())
                        data.append(item)
            self.patterns = data 

    
    def from_disk(self, path,*args, **kwargs):
        self.load_jsonl(path)
    
    def to_disk(self, path, *args, **kwargs):
        if not Path.exists(path):
            Path.mkdir(path)
        self.save_jsonl(self.patterns, path / "patterns.jsonl")
            
    def load_jsonl(self, file_path):
        data = []
        with open(file_path / "patterns.jsonl", 'r', encoding='utf-8') as file:
            for line in file:
                item = json.loads(line.strip())
                data.append(item)
        self.patterns = data 
       
    def save_jsonl(self, data, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            for item in data:
                line = json.dumps(item, ensure_ascii=False)
                file.write(line + '\n')
    
    def add_patterns(self, patterns):
        self.patterns = patterns
    
    def set_annotations2(self, doc, matches, label, exclude):
        """Modify the document in place"""
        entities = list(doc.ents)
        for match_id, start, end in matches:
            entities = [e for e in entities if not (e.start < end and e.end > start)]
            if exclude in ['FIRST', 'F', 'F1']:
                if (end - start) > 1:
                    start +=1
            elif exclude in ['LAST', 'L', 'L1']:
                if (end - start) > 1:
                    end -=1
            elif exclude in ['FIRST-LAST', 'F-L', 'F1-L1']:
                if (end - start) > 1:
                    start +=1
                    end -=1
            elif exclude in ['FIRST2', 'F2']:
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 2
            elif exclude in ['LAST2', 'L2']:
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    end -= 2
            elif exclude in ['FIRST2-LAST2', 'F2-L2']:
                if (end - start) > 3:  # Ensure there are at least 4 tokens in the entity
                    start += 2
                    end -= 2
            elif exclude == 'F2-L1':
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 2
                    end -= 1
            elif exclude == 'F1-L2':
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 1
                    end -= 2
            new_ent = Span(doc, start, end, label=label)
            doc.ents = entities + [new_ent]
          
    def set_annotations(self, doc, matches, label, exclude):
        """Modify the document in place"""
        entities = list(doc.ents)
        new_entities = []
        for match_id, start, end in matches:
            if exclude in ['FIRST', 'F', 'F1']:
                if (end - start) > 1:
                    start +=1
            elif exclude in ['LAST', 'L', 'L1']:
                if (end - start) > 1:
                    end -=1
            elif exclude in ['FIRST-LAST', 'F-L', 'F1-L1']:
                if (end - start) > 1:
                    start +=1
                    end -=1
            elif exclude in ['FIRST2', 'F2']:
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 2
            elif exclude in ['LAST2', 'L2']:
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    end -= 2
            elif exclude in ['FIRST2-LAST2', 'F2-L2']:
                if (end - start) > 3:  # Ensure there are at least 4 tokens in the entity
                    start += 2
                    end -= 2
            elif exclude == 'F2-L1':
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 2
                    end -= 1
            elif exclude == 'F1-L2':
                if (end - start) > 2:  # Ensure there are at least 3 tokens in the entity
                    start += 1
                    end -= 2
            # Verificar se os índices são válidos
            if start < end:
                new_ent = Span(doc, start, end, label=label)
                new_entities.append(new_ent)

            # Remover entidades que se sobrepõem com novas entidades
            entities = [e for e in entities if not any(new_e.start < e.end and new_e.end > e.start for new_e in new_entities)]
            doc.ents = entities + new_entities
    
    def __call__(self, doc):
        for pattern in self.patterns:
            label = pattern['label']
            token_patterns = pattern['pattern']
            if 'exclude' not in pattern:
                exclude = None
            else:
                exclude = pattern['exclude']
            matcher = Matcher(self.nlp.vocab)
            matcher.add(label, [token_patterns])
            matches = matcher(doc)
            self.set_annotations(doc, matches, label, exclude)
        return doc  

