import spacy
from spacy.tokenizer import Tokenizer
from spacy.language import Language
import re 

@spacy.registry.callbacks("customize_tokenizer")
def make_customize_tokenizer():
    def customize_tokenizer(nlp):
        nlp.tokenizer = Tokenizer(nlp.vocab, token_match=re.compile(r'\S+').match)
    return customize_tokenizer

# @Language.component("correct_errors")
# def correct_errors(doc):
#     keywords=[
#         {'CANADA':('RICHMOND', '')}
#     ]
#     cat = max(doc.cats, key=doc.cats.get)
#     cat_value = doc.cats[cat] 
#     if cat_value < 0.5:
#         for cat_name, cat_value in doc.cats.items():
#             doc.cats[cat_name]=0
#             if cat_name == 'CANADA':
#                 print(doc.text)
#                 doc.cats[cat_name]=1.0
#     return doc 




