| Feature | Description |
| --- | --- |
| **Name** | `xx_textcat_class` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.6.1,<3.7.0` |
| **Default Pipeline** | `textcat` |
| **Components** | `textcat` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (31 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat`** | `ROMANIA`, `BELGIUM`, `BRAZIL`, `DENMARK`, `MALTA`, `IRELAND`, `EL SALVADOR`, `GERMANY`, `ITALY`, `GREECE`, `NETHERLANDS`, `UNITED KINGDOM`, `CANADA`, `SWEDEN`, `MEXICO`, `SWITZERLAND`, `THAILAND`, `SPAIN`, `RUSSIA`, `BELARUS`, `FRANCE`, `KOREA`, `EGYPT`, `PORTUGAL`, `JORDAN`, `CHILE`, `NORTH MACEDONIA`, `HONG KONG`, `KOSOVO`, `POLAND`, `MONTENEGRO` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 81.17 |
| `CATS_MICRO_P` | 98.83 |
| `CATS_MICRO_R` | 98.83 |
| `CATS_MICRO_F` | 98.83 |
| `CATS_MACRO_P` | 81.51 |
| `CATS_MACRO_R` | 81.67 |
| `CATS_MACRO_F` | 81.17 |
| `CATS_MACRO_AUC` | 87.08 |
| `TEXTCAT_LOSS` | 1.85 |