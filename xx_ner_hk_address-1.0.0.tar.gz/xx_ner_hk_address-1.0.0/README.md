| Feature | Description |
| --- | --- |
| **Name** | `xx_ner_hk_address` |
| **Version** | `1.0.0` |
| **spaCy** | `>=3.6.1,<3.7.0` |
| **Default Pipeline** | `tok2vec`, `ner`, `entity_ruler`, `context_matcher_hk` |
| **Components** | `tok2vec`, `ner`, `entity_ruler`, `context_matcher_hk` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (17 labels for 2 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `ADR`, `BDT`, `BID`, `CIT`, `CNT`, `CSD`, `EML`, `PCD`, `PER`, `PHN`, `REG` |
| **`entity_ruler`** | `ADR`, `BDT`, `CIT`, `CSD`, `PHN`, `SIF` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `ENTS_F` | 98.61 |
| `ENTS_P` | 98.57 |
| `ENTS_R` | 98.64 |
| `TOK2VEC_LOSS` | 103415.41 |
| `NER_LOSS` | 1013397.67 |